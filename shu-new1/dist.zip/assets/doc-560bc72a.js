import{x as A,y as Y,z as Ut,A as re,B as ae,C as un,N as en,D as st,E as Ge,G as Le,H as zt,I as Gt,J as Jt,K as Yt,L as rt,M as An,O as qt,P as Zt,Q as Xt,R as Qt,S as xt,T as es,_ as ns,r as fe,U as ne,o as pe,c as Pe,F as $n,m as Ln,u as Ie,b as Z,V as ue,W as ts,a as he,t as Vn,q as ss}from"./index-024af3b0.js";const rs=[{title:"接口自动化",children:[{name:"pytest",content:""},{name:"requests",content:""},{name:"PyYAML",content:""},{name:"faker",content:""},{name:"allure",content:""}]},{title:"面向对象",children:[{name:"类",content:`<p>类与对象</p>
        <p>什么是面向对象，面向就是就是字面意思。脸朝向
          <br>朝向哪？朝向对象。
          <br>那什么是对象。一切皆对象。
          <br>现实生活中，无论什么，一个人也好，一个物品也好。都可以用“一个东西”代替
          <br>所以面向对象的意思就是把 脸朝向一个东西。。
        </p>
        <p>开玩笑，重来。面向的意思确实就是脸朝向某个方向。意思是让你写代码的时候往那个方向走，尽量往那边靠。
          <br>往哪边靠？对象上靠。对象是什么。记得怎么描述一个人吗？
          <br>人有身高，体重，年龄等特征。
          <br>人还会走路，会吃饭。
          <br>身高体重特征，其实也就是一个人属性。走路，吃饭是他的行为。代码里叫方法。
          <br>所以对象是什么，先简单看，对象就是把“一个东西”抽象成属性，和方法。
        </p>
        <p>
          ok，先来看怎么把一个东西在python代码里抽象成一个对象和一些关键字
        </p>
        <pre>
          <coed>
            class People():  //class 关键字 用于创建一个类。就像def 用于创建一个函数一样。
              name='肖战',    // 定义类的属性
              hair=['10厘米','11厘米']
              def shit(self):   // 定义类的方法
                print(self.name+'在**')

            a = People()   // 创建一个类的实例 People() 就是返回一个类的实例
            a.shit()       // 调用类的方法
            a.name         // 访问类的属性
          </coed>
        </pre>
        <p>
          这就是创建的一个对象，这里只有一个属性，一个方法。但其实只要想。可以把一个人所有的属性列出来。
          <br>比如 hair 属性,在这里是一个列表，因为头发有很多嘛，所以用列表来装，然后列表里是的值是每根头发的长度。属性可以是任何值，甚至是一个类。
        </p>

        <p>
          <span class="stress">为什么要这么做！为什么要把东西 抽象成对象。</span>
        </p>
        <p>
          <span class="stress">因为用这种模式，可以模拟世界上的任何东西，所有东西。都可以用属性，方法的模式，抽象成一个对象。</span>
        </p>
        <p>无论什么，一张桌子，它有长宽高的属性。一根头发，它有长度，是不是分叉了。</p>
        <p>
          并且，面向对象这种模式很易读。因为其实这种模式写出来的代码其实是非常贴近现实生活的。
          借用一个例子。
        </p>
        <p>

          <br>问题： 洗衣机里面放有脏衣服，怎么洗干净？

          <br>面向过程的解决方法：

          <br>1、执行加洗衣粉方法；

          <br>2、执行加水方法；

          <br>3、执行洗衣服方法；

          <br>4、执行清洗方法；

          <br>5、 执行烘干方法；

          <br>以上就是将解决这个问题的过程拆成一个个方法（是没有对象去调用的），通过一个个方法的执行来解决问题。

          <br>面向对象的解决方法：

          <br><br>1、我先弄出两个对象：“洗衣机”对象和“人”对象

          <br>2、针对对象“洗衣机”加入一些属性和方法：“洗衣服方法”“清洗方法”、“烘干方法”

          <br>3、针对对象“人”加入属性和方法：“加洗衣粉方法”、“加水方法”

          <br>4、然后执行

          <br>人.加洗衣粉()

          <br>人.加水()

          <br>洗衣机.洗衣服()

          <br>洗衣机.清洗()

          <br>洗衣机.烘干()

          <br>解决同一个问题 ，面向对象编程就是先抽象出对象，然后用对象执行方法的方式解决问题。
        </p>

        <p>
          面向对象和面向过程 都是代码的一种设计模式。面向对象 就是以对象为基础。面向过程以 过程为基础，也就是从上往下执行。
        </p>



        <p>其实面向对象并不难。语法上就是 class 类名(): 定义一个类。和 def 定义方法一样。
          <br>然后在这个类里定义的变量是这个类的属性。在这个类里定义的函数是类的方法。
          <br>类被定义后是不能直接用的。需要实例化。语法是 类名跟一个括号 类名()
          <br>类名()就是返回一个类的实例，实例就可以通过 实例.属性  实例.方法这样的语法访问类的属性和方法
          <br>class 类名(): 就是在定义一个摸具，而 类名() 就是在用材料填充摸具，并返回一个真正可用的实例。材料就是传递的参数。
        </p>
        <p class="stress">
          其实面向对象并不难，定义一个类就是一个对象摸具，对象里可以定义属性和方法，用来描述这个对象有什么特征，能做什么事情
        </p>
        <p class="stress">
          月饼摸具是不可以吃的，但月饼是可以吃的对吧。所以要使用这些属性和方法需要先实例化。实例化后就可以使用 实例.属性 实例.方法的模式访问类里定义属性和方法了
        </p>`},{name:"封装",content:""},{name:"继承",content:""},{name:"多态",content:""}]},{title:"Python 主体",children:[{name:"简介",content:`<p>python 是一门解释型，动态类型的编程语言</p>
        <p>当然还有其他标签，不重要。先了解一下什么是解释型和动态类型。</p>
        <p>解释型语言
          <br>
          <br>关于解释型相关的定义一共又俩种。分别是 解释性语言 和 编译型语言。
          <br>解释型的意思是 你的代码写出来后不需要编译就可以直接运行。
          <br>聪明的你肯定想到了，那代码写出来当然要可以运行，不能运行不就是报错了嘛？
          <br>并不是，还有和解释型不同的另一种类型的语言。叫编译型语言。比如C，C++。它们的代码写出来后需要先编译成文件才能运行。比如我们常见的 .exe 文件。就是编译打包后的文件。
          <br>其实 python 代码写出来后也是要编译才能运行的。只是它不用预编译。它是在运行时才通过 python解释器 进行编译
          <br>所以，所谓的解释型 和 编译型 语言。都是需要编译的，只是编译的时机不同。
        </p>
        <p>
          动态类型。
          <br>
          <br>关于动态类型这种定义一共又四种。分别是 动态/静态 类型， 强/弱 类型。
          <br>动态和静态 是相对的，强和弱是相对的。
          <br>动态类型，其实就是这门语言规定 代码里在编译之前 不需要 确定变量的数据类型。对应的 静态类型 是 需要确定，不然会编译不通过。
          <br>
          <br>而强类型。则是指这门语言的 变量 的数据类型，如果不强制转换（认为写代码转换），那么这个变量的数据类型是不会改变的。弱类型则是可能会改变的（隐式转换）。
          <br>不懂这个概念可能会有点迷茫，不急。。这里还没想好******下次补充 还是协议，规矩的事。解决某些问题，设立的某些规矩。
        </p>
        <pre>
          <code>
            a = "17" - 11
            print(a)
          </code>
        </pre>
        <p>python是强类型语言，上面这行代码是会报错的！因为用字符串的“17” 和 数字11 做减法运算。
          <br>但在弱类型语言里，它可以正确的运算出来等于 6。
          <br>原因是弱类型语言它在做这个运算的时候，它发现 减号俩边一个是字符串，一个是数字。它会自动把数据类型转换成一样的，才会再去做运算。这就是<span class="stress">隐式转换。</span>
          <br>python 这种强类型语言，如果发现类型不一致，或者这个数据类型不能用这个运算符。它则是会直接抛出bug，让你去解决。如果你要算的话你就得手动写一句代码 int() 函数转换类型。这就是<span class="stress">强制转换。</span>
        </p>

        <p>总结：
          <br>1、python 是无需“提前编译”，它是一边编译一边运行的 解释型语言。
          <br>2、python 是动态类型，不需要在编译前就确定类型。
          <br>3、python 是强类型语言，如果要改变一个 变量的数据类型 只能强制转换。
          <br>
          <br>其实这些东西 都是人为了解决一些问题，在某些时候更方便使用。所立下的规矩。
          <br>比如第1条，不需要 提前编译，直接拿着写好的代码文件就可以直接运行，写好了就可以直接用，方便传播，对平台的依赖小一些。它就比c++那些需要提前编译的语言适用面更广。比如APP需要提前下载使用，而H5可以直接打开。
          <br>第3条 就更离谱了，强类型语言，它最大的作用就是尽量保证少出bug。所立下的规矩。
        </p>
        <p>建议
          <br>这些大致了解一下，知道它设立 这种规矩 是要解决什么问题，知道可能会出什么BUG就行，不必太深究。
        </p>`},{name:"变量",content:`<P>
          <el-tag>数字</el-tag>
          <el-tag>字符串</el-tag>
          <el-tag>列表</el-tag>
          <el-tag>元组</el-tag>
          <el-tag>字典</el-tag>
          <el-tag>集合</el-tag>
        </P>
        <p>变量与数据类型</p>

        <pre>
          <code>
            a = 1                                    // 数字
            b = '王琪'                                // 字符串
            c = ['王琪','吴彦祖','胡歌','彭于晏']        // 列表
            d = ('a','b','c')                        // 元组
            e = {'height':'180cm','age':'18'}        // 字典
            f = {'王琪','吴彦祖','胡歌'}                // 集合
          </code>
        </pre>

        <p>
          数字类型：
          <br>包含三个子项，分别是 整数int 浮点数float。
          <br>一般主要用于计算。
        </p>
        <p>字符串：
          <br>属于序列的一种，就像整数int和浮点数float都是数字。
          <br>一般用于文字输入输出，是很万能的一个数据格式。
          <br>
          <br>字符串，列表，元组，这三个是python里的序列了。
          <br>序列最长利用到的特性就是可迭代，有顺序，可以通过下标访问了。
          <br>而它们三个都是序列所以他们也有这些特性。
        </p>
        <p>
          列表：
          <br>属于序列的一种
          <br>一般用于一组重复相同的数据，例如，公司有20个人。为了方便使用就放一个变量里。
          <br>一般代码里用于for 或while 循环里访问所有值。或者使用下标访问单个值
          <br>特点是可以用下标访问，可迭代（循环），有顺序。如上面代码：彭于晏排名第四。
        </p>
        <p>元组：
          <br>属于序列的一种
          <br>其实元组可以直接看成不可变的数组。
          <br>特点是开始定义它之后就不能对它的值进行修改了，其他和序列差不多
        </p>
        <p>
          字典：
          <br>由多个 键值对 组成，通过键名来访问值。
          <br>字典与列表的不同在于，列表更倾向于存放 重复相同的数据。比如20个员工列表。他们都是员工，所以放列表里合适。
          <br>而字典 更倾向于 不同意义的值。比如某个员工，他年龄，身高，体重，姓名等等。这些值提取不出什么共同点，所以通过键值对的方式去存放比较合适。
          <br>特点是通过 .键名的方式访问 例如：a.age。
        </p>
        <p>
          集合：
          <br>集合也是序列的一种
          <br>但它是无序的。。
          <br>说实话，集合除了一些方法在某些时候很方便，比如去重，查看是否包含。比如我要找王琪是不是属于某个公司。但我实在没想出来它具体的应用场景，因为这些事字典和列表都可以代替。
          <br>特点，无序的可迭代对象，实在有点扯。也就是说循环的时候压根不知道第一个，第二个循环的是谁。是随机的。如上面代码，大致意思就是排名不分先后。
        </p>

        <p>
          这是 python 提供的六种数据类型。同样的创造他们就是为了各自解决某些方面的事的。比如数字用于计算，比如列表用于循环。等等。。
          <br>
          <br>它们的区别在于 存储方式不同，可用的属性和方法不同。
          <br>存储方式不同不多说了。
          <br>可用的属性和方法不同，比如说序列类型，都可以通过len方法获得 它的长度。
          <br>数字有很多用于计算的方法，比如abs() 绝对值 ceil()向上取整等等。
          <br>字符串 有转换大小写等
          <br>列表有新增删除列表项等
          <br>这里需要知道它们都有哪些方法，怎么用。下面是每个数据类型的常用的比较重要的方法
        </p>

        <p>常用方法******</p>

        <p>
          上面说的是 python 提供记得基础类型。它们都是为了解决某个方面的问题，创造出来的。你也可以创造自己的数据类型。
          <br>比如队列，先进先出。栈，先进后出（羽毛球桶），链表等。
          <br>现在不用管它们怎么实现。理解一个概念。
          <br>设计 队列 这个数据类型，就是方便解决 排队这种需求场景下的问题。
        </p>`},{name:"逻辑控制",content:{}},{name:"函数",content:{}},{name:"其他规则",content:{}}]},{title:"计算机",children:[{name:"语言",content:`<p>计算机工作原理和语言的关系</p>
        <p>想一想计算机能做什么？</p>
        <p>先抛开一切，计算机只有0和1对吧。那么不管你在计算机上做什么事情。打游戏，看电视什么都好。</p>
        <p>最终</p>
        <p>计算机都是在对 那无数个 0和1 做增删改查。</p>
        <p>对吧，计算机cpu 只有0和1呀。那些协议，都是把这些01变成 人能看懂的东西。</p>
        <p>比如，一个电影。存成MP4格式文件。500M吧</p>
        <p>这里提一下，计算机里一个0或1等于 1 bit。bit是计算机里最小的单位了。
          <br>完整单位换算如下。
          <br>8bit = 1B
          <br>1024B = 1KB
          <br>1024KB = 1MB
          <br>1024MB = 1GB
          <br>1024GB = 1TB
          <br>上面还有...但最小就是从 bit 开始了。因为bit 等于 一个0或1嘛。
          <br>M就是MB的意思，也不用区分大小写mb也行的
        </p>
        <p>说回电影，一个500M的电影文件，存在电脑里，意思就是这个电影文件需要占用 500 * 1024 * 1024 * 8=4194304000个0</p>
        <p>别算了，41亿9千多万</p>
        <p>而电影的mp4格式也是一种协议呀。这个协议的作用，简单来说就是把41亿个 01 解析成人类能看懂的画面。</p>
        <p>所以，计算机做的事情简单概括一下就俩个
          <span class="stress">
          <br>1、对 0 和 1 做增删改查
          <br>2、通过各种协议把 01 转变成人能看懂的东西，或者相反，把人能看懂的东西转变成 01 存起来。
            </span>
        </p>
        <p>这是计算机的工作原理，再简单说一下语言的发展，这个了解，知道一下就行，和上面的第二条差不多，其实是一个意思</p>
        <p>
          计算机只有0和1对吧。0和1是什么，是一个开关对吧。
          <br>所以从硬件层面来说，人能操作的就是一个个的去开“开关”，关“开关”
          <br>但一个个去开关太麻烦了，人们就把开关的操作封装了一下。比如一次可以把所有开关都打开或关闭。或者打开一半等等。。
          <br>这就是 汇编，但是汇编还是太晦涩难懂的，然后用汇编写了 C 语言。
          <br>然后人们还是觉得C语言写代码有点麻烦，又封装了一下变成 C++。
          <br>语言的发展就是这样的。。嫌麻烦，然后封装一下。。
          <br>汇编 => C/C++ => 其他语言
        </p>`},{name:"协议",content:`<p><span class="stress">计算机就是由无数的协议堆砌而成！</span></p>
        <p>协议，也可以说是约定好的一种制度，一个规矩，一个标准。大家商量好的，都按这个来。就好像 “我” = “me” 一样。</p>
        <p>计算机由 0 和 1 组成，连 2 都没有，理论上来说计算机只能表示 0 和 1。<br>
          但人发明了二进制，用进位的方式来表示更多的数字。二进制立了一个规矩。虽然我只有 0 和 1 ，但我有很多个0和1。所以我用俩位数字 “10” 来表示 2。“11”表示 3。依次类推
          <br>二进制就是计算机里第一个，也是最基础的协议。
          <br>二进制让计算机拥有了 用无数个 0 和 1 表示 无数个数字的能力。
        </p>

        <p>有了无数个数字，事情就变得简单有趣起来。
          <br>小时候考试有没有作过弊，一个手指选A，俩个手指选B。。。
          <br>或者，有没有和小伙伴有过什么密语。
          <br>其实这就是计算机的原理，用一些东西代指某些东西。
          <br>计算机里只有 0 和 1，但可以用二进制表示其他数字。然后可以用这些数字表示其他意思。
          <br>比如汉字，英文，符号等等。本质都是数字，然后用数字去字符集里找对应的值（ASCII，Unicode，GB/T 2312-1980，它们三个都是字符集，只是收录的字符不同，这个只要知道字符其实都是用数字从这些表里找出来的就行）
          <br>字符集就是 编号后的字符集合，把 abcd，0123，周五阵亡。这些字每个编上独一无二的号码（数字）。然后可以通过数字来一一对应
          <br>因此，Python和大部分语言中字符串可以比较大小。因为他们本质上是数字。ord() 函数 可以将字符串获得传入字符串的 字符值！
          <br>
        </p>
        <p>
          有了文字，就可以组成关键字了，就可以开始写代码了呀。Python语言里的大部分关键字其实都是字面意思
          <br>比如 if 。翻译成中文就是如果的意思 python 里 if 后面跟一个条件语句，如果为真就执行，为假就不执行。
          <br>所以 if age>15:  外国人看就是 （如果 年龄 大于 15：）
          <br>
          <br>
          所以，其实很简单，计算机嘛，只有01。于是用0和1来表示数字，然后用数字通过字符集来表示文字。然后。。。
        </p>
        <p>
          <span class="stress">这章很重要。理解协议，理解 计算机 是怎么通过一个个协议从 01 变得 无所不能。</span>
        </p>`},{name:"进制",content:`<p>
          <el-tag>二进制</el-tag>
          <el-tag>八进制</el-tag>
          <el-tag>十进制</el-tag>
          <el-tag>十六进制</el-tag>
        </p>
        <p>官方解释：进制也就是进位计数制，是人为定义的带进位的计数方法，对于任何一种进制---X进制，就表示每一位上的数运算时都是逢X进一位。 十进制是逢十进一，十六进制是逢十六进一，二进制就是逢二进一，以此类推，x进制就是逢x进位。</p>
        <p>进制，就是在数数的时候，每碰到一个固定的数字就需要往前进一位的制度；简称为“进制”。</p>
        <p>
          比如十进制，数字是0~9，我从0开始数起。0,1,2...8,9。数到 9 正常再往下是数不下去了。因为一共就 0~9 十位数字。
          这个时候就需要往前进一个 1 。也就是 “十位加一，个位归零”。 其实这个 “1” 就代表着我已经把 0~9 数过一遍了，接下来我是数第二遍了。第二遍数完，
          又往前（十位）进一个 1 ，与之前（十位）的1相加。如果十位也加到 9 了。就开始往百位加一。类推。
        </p>
        <p>
          二进制也是一样的。二进制数字只有 0~1 。所以每次数到 1 之后，再要往下数，就往要前加 1 。
          二进制与日常用的十进制唯一不同的就是 缝几进一 的不同了。理解它们的共同点。
        </p>
        <p>常用的进制有二进制，八进制，十进制，十六进制。八进制其实接触的少。十六进制接触的多的是 颜色的值。如#FFF。F就是十六进制的十五。0~9 a(10) , b(11),c,d,e,f(15)</p>
        <p>同时在Python里可以直接写出不同进制的数字，只是需要加一些前缀</p>
        <pre>
          <code>
    a = 0b10001 // 二进制 17 前缀0b 后面跟0~1 <br>
    b = 0o21    // 八进制 17 前缀0o 后面跟0~7的数字 <br>
    c = 17      // 十进制 17 <br>
    d = 0x11    // 十六进制 17 前缀0x 后面跟 0~9 a~f
          </code>
        </pre>
        <p>思考一下，0b10，0o10，0x10等于十进制的多少，总结一下规律</p>`}]}];function hn(e){throw e}function it(e){}function P(e,n,t,s){const r=e,i=new SyntaxError(String(r));return i.code=e,i.loc=n,i}const ye=Symbol(""),me=Symbol(""),dn=Symbol(""),Ve=Symbol(""),lt=Symbol(""),x=Symbol(""),ot=Symbol(""),ct=Symbol(""),mn=Symbol(""),gn=Symbol(""),Te=Symbol(""),yn=Symbol(""),at=Symbol(""),bn=Symbol(""),Be=Symbol(""),Sn=Symbol(""),En=Symbol(""),vn=Symbol(""),_n=Symbol(""),ft=Symbol(""),pt=Symbol(""),Je=Symbol(""),De=Symbol(""),Tn=Symbol(""),Nn=Symbol(""),be=Symbol(""),Ne=Symbol(""),Cn=Symbol(""),sn=Symbol(""),is=Symbol(""),rn=Symbol(""),Fe=Symbol(""),ls=Symbol(""),os=Symbol(""),On=Symbol(""),cs=Symbol(""),as=Symbol(""),kn=Symbol(""),ut=Symbol(""),ie={[ye]:"Fragment",[me]:"Teleport",[dn]:"Suspense",[Ve]:"KeepAlive",[lt]:"BaseTransition",[x]:"openBlock",[ot]:"createBlock",[ct]:"createElementBlock",[mn]:"createVNode",[gn]:"createElementVNode",[Te]:"createCommentVNode",[yn]:"createTextVNode",[at]:"createStaticVNode",[bn]:"resolveComponent",[Be]:"resolveDynamicComponent",[Sn]:"resolveDirective",[En]:"resolveFilter",[vn]:"withDirectives",[_n]:"renderList",[ft]:"renderSlot",[pt]:"createSlots",[Je]:"toDisplayString",[De]:"mergeProps",[Tn]:"normalizeClass",[Nn]:"normalizeStyle",[be]:"normalizeProps",[Ne]:"guardReactiveProps",[Cn]:"toHandlers",[sn]:"camelize",[is]:"capitalize",[rn]:"toHandlerKey",[Fe]:"setBlockTracking",[ls]:"pushScopeId",[os]:"popScopeId",[On]:"withCtx",[cs]:"unref",[as]:"isRef",[kn]:"withMemo",[ut]:"isMemoSame"};function fs(e){Object.getOwnPropertySymbols(e).forEach(n=>{ie[n]=e[n]})}const W={source:"",start:{line:1,column:1,offset:0},end:{line:1,column:1,offset:0}};function ps(e,n=W){return{type:0,children:e,helpers:new Set,components:[],directives:[],hoists:[],imports:[],cached:0,temps:0,codegenNode:void 0,loc:n}}function Se(e,n,t,s,r,i,l,o=!1,c=!1,a=!1,p=W){return e&&(o?(e.helper(x),e.helper(ce(e.inSSR,a))):e.helper(oe(e.inSSR,a)),l&&e.helper(vn)),{type:13,tag:n,props:t,children:s,patchFlag:r,dynamicProps:i,directives:l,isBlock:o,disableTracking:c,isComponent:a,loc:p}}function Ce(e,n=W){return{type:17,loc:n,elements:e}}function j(e,n=W){return{type:15,loc:n,properties:e}}function I(e,n){return{type:16,loc:W,key:A(e)?S(e,!0):e,value:n}}function S(e,n=!1,t=W,s=0){return{type:4,loc:t,content:e,isStatic:n,constType:n?3:s}}function G(e,n=W){return{type:8,loc:n,children:e}}function M(e,n=[],t=W){return{type:14,loc:t,callee:e,arguments:n}}function le(e,n=void 0,t=!1,s=!1,r=W){return{type:18,params:e,returns:n,newline:t,isSlot:s,loc:r}}function ln(e,n,t,s=!0){return{type:19,test:e,consequent:n,alternate:t,newline:s,loc:W}}function us(e,n,t=!1){return{type:20,index:e,value:n,isVNode:t,loc:W}}function hs(e){return{type:21,body:e,loc:W}}const F=e=>e.type===4&&e.isStatic,se=(e,n)=>e===n||e===Ut(n);function ht(e){if(se(e,"Teleport"))return me;if(se(e,"Suspense"))return dn;if(se(e,"KeepAlive"))return Ve;if(se(e,"BaseTransition"))return lt}const ds=/^\d|[^\$\w]/,Pn=e=>!ds.test(e),ms=/[A-Za-z_$\xA0-\uFFFF]/,gs=/[\.\?\w$\xA0-\uFFFF]/,ys=/\s+[.[]\s*|\s*[.[]\s+/g,bs=e=>{e=e.trim().replace(ys,l=>l.trim());let n=0,t=[],s=0,r=0,i=null;for(let l=0;l<e.length;l++){const o=e.charAt(l);switch(n){case 0:if(o==="[")t.push(n),n=1,s++;else if(o==="(")t.push(n),n=2,r++;else if(!(l===0?ms:gs).test(o))return!1;break;case 1:o==="'"||o==='"'||o==="`"?(t.push(n),n=3,i=o):o==="["?s++:o==="]"&&(--s||(n=t.pop()));break;case 2:if(o==="'"||o==='"'||o==="`")t.push(n),n=3,i=o;else if(o==="(")r++;else if(o===")"){if(l===e.length-1)return!1;--r||(n=t.pop())}break;case 3:o===i&&(n=t.pop(),i=null);break}}return!s&&!r},dt=bs;function mt(e,n,t){const r={source:e.source.slice(n,n+t),start:He(e.start,e.source,n),end:e.end};return t!=null&&(r.end=He(e.start,e.source,n+t)),r}function He(e,n,t=n.length){return We(Y({},e),n,t)}function We(e,n,t=n.length){let s=0,r=-1;for(let i=0;i<t;i++)n.charCodeAt(i)===10&&(s++,r=i);return e.offset+=t,e.line+=s,e.column=r===-1?e.column+t:t-r,e}function K(e,n,t=!1){for(let s=0;s<e.props.length;s++){const r=e.props[s];if(r.type===7&&(t||r.exp)&&(A(n)?r.name===n:n.test(r.name)))return r}}function Ye(e,n,t=!1,s=!1){for(let r=0;r<e.props.length;r++){const i=e.props[r];if(i.type===6){if(t)continue;if(i.name===n&&(i.value||s))return i}else if(i.name==="bind"&&(i.exp||s)&&X(i.arg,n))return i}}function X(e,n){return!!(e&&F(e)&&e.content===n)}function Ss(e){return e.props.some(n=>n.type===7&&n.name==="bind"&&(!n.arg||n.arg.type!==4||!n.arg.isStatic))}function nn(e){return e.type===5||e.type===2}function Es(e){return e.type===7&&e.name==="slot"}function Ke(e){return e.type===1&&e.tagType===3}function je(e){return e.type===1&&e.tagType===2}function oe(e,n){return e||n?mn:gn}function ce(e,n){return e||n?ot:ct}const vs=new Set([be,Ne]);function gt(e,n=[]){if(e&&!A(e)&&e.type===14){const t=e.callee;if(!A(t)&&vs.has(t))return gt(e.arguments[0],n.concat(e))}return[e,n]}function Ue(e,n,t){let s,r=e.type===13?e.props:e.arguments[2],i=[],l;if(r&&!A(r)&&r.type===14){const o=gt(r);r=o[0],i=o[1],l=i[i.length-1]}if(r==null||A(r))s=j([n]);else if(r.type===14){const o=r.arguments[0];!A(o)&&o.type===15?Bn(n,o)||o.properties.unshift(n):r.callee===Cn?s=M(t.helper(De),[j([n]),r]):r.arguments.unshift(j([n])),!s&&(s=r)}else r.type===15?(Bn(n,r)||r.properties.unshift(n),s=r):(s=M(t.helper(De),[j([n]),r]),l&&l.callee===Ne&&(l=i[i.length-2]));e.type===13?l?l.arguments[0]=s:e.props=s:l?l.arguments[0]=s:e.arguments[2]=s}function Bn(e,n){let t=!1;if(e.key.type===4){const s=e.key.content;t=n.properties.some(r=>r.key.type===4&&r.key.content===s)}return t}function Ee(e,n){return`_${n}_${e.replace(/[^\w]/g,(t,s)=>t==="-"?"_":e.charCodeAt(s).toString())}`}function _s(e){return e.type===14&&e.callee===kn?e.arguments[1].returns:e}function In(e,{helper:n,removeHelper:t,inSSR:s}){e.isBlock||(e.isBlock=!0,t(oe(s,e.isComponent)),n(x),n(ce(s,e.isComponent)))}function Dn(e,n){const t=n.options?n.options.compatConfig:n.compatConfig,s=t&&t[e];return e==="MODE"?s||3:s}function Q(e,n){const t=Dn("MODE",n),s=Dn(e,n);return t===3?s===!0:s!==!1}function ve(e,n,t,...s){return Q(e,n)}const Ts=/&(gt|lt|amp|apos|quot);/g,Ns={gt:">",lt:"<",amp:"&",apos:"'",quot:'"'},Fn={delimiters:["{{","}}"],getNamespace:()=>0,getTextMode:()=>0,isVoidTag:en,isPreTag:en,isCustomElement:en,decodeEntities:e=>e.replace(Ts,(n,t)=>Ns[t]),onError:hn,onWarn:it,comments:!1};function Cs(e,n={}){const t=Os(e,n),s=H(t);return ps(Mn(t,0,[]),z(t,s))}function Os(e,n){const t=Y({},Fn);let s;for(s in n)t[s]=n[s]===void 0?Fn[s]:n[s];return{options:t,column:1,line:1,offset:0,originalSource:e,source:e,inPre:!1,inVPre:!1,onWarn:t.onWarn}}function Mn(e,n,t){const s=qe(t),r=s?s.ns:0,i=[];for(;!Ls(e,n,t);){const o=e.source;let c;if(n===0||n===1){if(!e.inVPre&&B(o,e.options.delimiters[0]))c=As(e,n);else if(n===0&&o[0]==="<")if(o.length===1)_(e,5,1);else if(o[1]==="!")B(o,"<!--")?c=Ps(e):B(o,"<!DOCTYPE")?c=de(e):B(o,"<![CDATA[")?r!==0?c=ks(e,t):(_(e,1),c=de(e)):(_(e,11),c=de(e));else if(o[1]==="/")if(o.length===2)_(e,5,2);else if(o[2]===">"){_(e,14,2),R(e,3);continue}else if(/[a-z]/i.test(o[2])){_(e,23),on(e,1,s);continue}else _(e,12,2),c=de(e);else/[a-z]/i.test(o[1])?(c=Is(e,t),Q("COMPILER_NATIVE_TEMPLATE",e)&&c&&c.tag==="template"&&!c.props.some(a=>a.type===7&&yt(a.name))&&(c=c.children)):o[1]==="?"?(_(e,21,1),c=de(e)):_(e,12,1)}if(c||(c=$s(e,n)),re(c))for(let a=0;a<c.length;a++)Hn(i,c[a]);else Hn(i,c)}let l=!1;if(n!==2&&n!==1){const o=e.options.whitespace!=="preserve";for(let c=0;c<i.length;c++){const a=i[c];if(a.type===2)if(e.inPre)a.content=a.content.replace(/\r\n/g,`
`);else if(/[^\t\r\n\f ]/.test(a.content))o&&(a.content=a.content.replace(/[\t\r\n\f ]+/g," "));else{const p=i[c-1],f=i[c+1];!p||!f||o&&(p.type===3&&f.type===3||p.type===3&&f.type===1||p.type===1&&f.type===3||p.type===1&&f.type===1&&/[\r\n]/.test(a.content))?(l=!0,i[c]=null):a.content=" "}else a.type===3&&!e.options.comments&&(l=!0,i[c]=null)}if(e.inPre&&s&&e.options.isPreTag(s.tag)){const c=i[0];c&&c.type===2&&(c.content=c.content.replace(/^\r?\n/,""))}}return l?i.filter(Boolean):i}function Hn(e,n){if(n.type===2){const t=qe(e);if(t&&t.type===2&&t.loc.end.offset===n.loc.start.offset){t.content+=n.content,t.loc.end=n.loc.end,t.loc.source+=n.loc.source;return}}e.push(n)}function ks(e,n){R(e,9);const t=Mn(e,3,n);return e.source.length===0?_(e,6):R(e,3),t}function Ps(e){const n=H(e);let t;const s=/--(\!)?>/.exec(e.source);if(!s)t=e.source.slice(4),R(e,e.source.length),_(e,7);else{s.index<=3&&_(e,0),s[1]&&_(e,10),t=e.source.slice(4,s.index);const r=e.source.slice(0,s.index);let i=1,l=0;for(;(l=r.indexOf("<!--",i))!==-1;)R(e,l-i+1),l+4<r.length&&_(e,16),i=l+1;R(e,s.index+s[0].length-i+1)}return{type:3,content:t,loc:z(e,n)}}function de(e){const n=H(e),t=e.source[1]==="?"?1:2;let s;const r=e.source.indexOf(">");return r===-1?(s=e.source.slice(t),R(e,e.source.length)):(s=e.source.slice(t,r),R(e,r+1)),{type:3,content:s,loc:z(e,n)}}function Is(e,n){const t=e.inPre,s=e.inVPre,r=qe(n),i=on(e,0,r),l=e.inPre&&!t,o=e.inVPre&&!s;if(i.isSelfClosing||e.options.isVoidTag(i.tag))return l&&(e.inPre=!1),o&&(e.inVPre=!1),i;n.push(i);const c=e.options.getTextMode(i,r),a=Mn(e,c,n);n.pop();{const p=i.props.find(f=>f.type===6&&f.name==="inline-template");if(p&&ve("COMPILER_INLINE_TEMPLATE",e,p.loc)){const f=z(e,i.loc.end);p.value={type:2,content:f.source,loc:f}}}if(i.children=a,cn(e.source,i.tag))on(e,1,r);else if(_(e,24,0,i.loc.start),e.source.length===0&&i.tag.toLowerCase()==="script"){const p=a[0];p&&B(p.loc.source,"<!--")&&_(e,8)}return i.loc=z(e,i.loc.start),l&&(e.inPre=!1),o&&(e.inVPre=!1),i}const yt=ae("if,else,else-if,for,slot");function on(e,n,t){const s=H(e),r=/^<\/?([a-z][^\t\r\n\f />]*)/i.exec(e.source),i=r[1],l=e.options.getNamespace(i,t);R(e,r[0].length),_e(e);const o=H(e),c=e.source;e.options.isPreTag(i)&&(e.inPre=!0);let a=Wn(e,n);n===0&&!e.inVPre&&a.some(h=>h.type===7&&h.name==="pre")&&(e.inVPre=!0,Y(e,o),e.source=c,a=Wn(e,n).filter(h=>h.name!=="v-pre"));let p=!1;if(e.source.length===0?_(e,9):(p=B(e.source,"/>"),n===1&&p&&_(e,4),R(e,p?2:1)),n===1)return;let f=0;return e.inVPre||(i==="slot"?f=2:i==="template"?a.some(h=>h.type===7&&yt(h.name))&&(f=3):Ms(i,a,e)&&(f=1)),{type:1,ns:l,tag:i,tagType:f,props:a,isSelfClosing:p,children:[],loc:z(e,s),codegenNode:void 0}}function Ms(e,n,t){const s=t.options;if(s.isCustomElement(e))return!1;if(e==="component"||/^[A-Z]/.test(e)||ht(e)||s.isBuiltInComponent&&s.isBuiltInComponent(e)||s.isNativeTag&&!s.isNativeTag(e))return!0;for(let r=0;r<n.length;r++){const i=n[r];if(i.type===6){if(i.name==="is"&&i.value){if(i.value.content.startsWith("vue:"))return!0;if(ve("COMPILER_IS_ON_ELEMENT",t,i.loc))return!0}}else{if(i.name==="is")return!0;if(i.name==="bind"&&X(i.arg,"is")&&ve("COMPILER_IS_ON_ELEMENT",t,i.loc))return!0}}}function Wn(e,n){const t=[],s=new Set;for(;e.source.length>0&&!B(e.source,">")&&!B(e.source,"/>");){if(B(e.source,"/")){_(e,22),R(e,1),_e(e);continue}n===1&&_(e,3);const r=Rs(e,s);r.type===6&&r.value&&r.name==="class"&&(r.value.content=r.value.content.replace(/\s+/g," ").trim()),n===0&&t.push(r),/^[^\t\r\n\f />]/.test(e.source)&&_(e,15),_e(e)}return t}function Rs(e,n){const t=H(e),r=/^[^\t\r\n\f />][^\t\r\n\f />=]*/.exec(e.source)[0];n.has(r)&&_(e,2),n.add(r),r[0]==="="&&_(e,19);{const o=/["'<]/g;let c;for(;c=o.exec(r);)_(e,17,c.index)}R(e,r.length);let i;/^[\t\r\n\f ]*=/.test(e.source)&&(_e(e),R(e,1),_e(e),i=ws(e),i||_(e,13));const l=z(e,t);if(!e.inVPre&&/^(v-[A-Za-z0-9-]|:|\.|@|#)/.test(r)){const o=/(?:^v-([a-z0-9-]+))?(?:(?::|^\.|^@|^#)(\[[^\]]+\]|[^\.]+))?(.+)?$/i.exec(r);let c=B(r,"."),a=o[1]||(c||B(r,":")?"bind":B(r,"@")?"on":"slot"),p;if(o[2]){const h=a==="slot",u=r.lastIndexOf(o[2]),d=z(e,Kn(e,t,u),Kn(e,t,u+o[2].length+(h&&o[3]||"").length));let m=o[2],y=!0;m.startsWith("[")?(y=!1,m.endsWith("]")?m=m.slice(1,m.length-1):(_(e,27),m=m.slice(1))):h&&(m+=o[3]||""),p={type:4,content:m,isStatic:y,constType:y?3:0,loc:d}}if(i&&i.isQuoted){const h=i.loc;h.start.offset++,h.start.column++,h.end=He(h.start,i.content),h.source=h.source.slice(1,-1)}const f=o[3]?o[3].slice(1).split("."):[];return c&&f.push("prop"),a==="bind"&&p&&f.includes("sync")&&ve("COMPILER_V_BIND_SYNC",e,l,p.loc.source)&&(a="model",f.splice(f.indexOf("sync"),1)),{type:7,name:a,exp:i&&{type:4,content:i.content,isStatic:!1,constType:0,loc:i.loc},arg:p,modifiers:f,loc:l}}return!e.inVPre&&B(r,"v-")&&_(e,26),{type:6,name:r,value:i&&{type:2,content:i.content,loc:i.loc},loc:l}}function ws(e){const n=H(e);let t;const s=e.source[0],r=s==='"'||s==="'";if(r){R(e,1);const i=e.source.indexOf(s);i===-1?t=ge(e,e.source.length,4):(t=ge(e,i,4),R(e,1))}else{const i=/^[^\t\r\n\f >]+/.exec(e.source);if(!i)return;const l=/["'<=`]/g;let o;for(;o=l.exec(i[0]);)_(e,18,o.index);t=ge(e,i[0].length,4)}return{content:t,isQuoted:r,loc:z(e,n)}}function As(e,n){const[t,s]=e.options.delimiters,r=e.source.indexOf(s,t.length);if(r===-1){_(e,25);return}const i=H(e);R(e,t.length);const l=H(e),o=H(e),c=r-t.length,a=e.source.slice(0,c),p=ge(e,c,n),f=p.trim(),h=p.indexOf(f);h>0&&We(l,a,h);const u=c-(p.length-f.length-h);return We(o,a,u),R(e,s.length),{type:5,content:{type:4,isStatic:!1,constType:0,content:f,loc:z(e,l,o)},loc:z(e,i)}}function $s(e,n){const t=n===3?["]]>"]:["<",e.options.delimiters[0]];let s=e.source.length;for(let l=0;l<t.length;l++){const o=e.source.indexOf(t[l],1);o!==-1&&s>o&&(s=o)}const r=H(e);return{type:2,content:ge(e,s,n),loc:z(e,r)}}function ge(e,n,t){const s=e.source.slice(0,n);return R(e,n),t===2||t===3||!s.includes("&")?s:e.options.decodeEntities(s,t===4)}function H(e){const{column:n,line:t,offset:s}=e;return{column:n,line:t,offset:s}}function z(e,n,t){return t=t||H(e),{start:n,end:t,source:e.originalSource.slice(n.offset,t.offset)}}function qe(e){return e[e.length-1]}function B(e,n){return e.startsWith(n)}function R(e,n){const{source:t}=e;We(e,t,n),e.source=t.slice(n)}function _e(e){const n=/^[\t\r\n\f ]+/.exec(e.source);n&&R(e,n[0].length)}function Kn(e,n,t){return He(n,e.originalSource.slice(n.offset,t),t)}function _(e,n,t,s=H(e)){t&&(s.offset+=t,s.column+=t),e.options.onError(P(n,{start:s,end:s,source:""}))}function Ls(e,n,t){const s=e.source;switch(n){case 0:if(B(s,"</")){for(let r=t.length-1;r>=0;--r)if(cn(s,t[r].tag))return!0}break;case 1:case 2:{const r=qe(t);if(r&&cn(s,r.tag))return!0;break}case 3:if(B(s,"]]>"))return!0;break}return!s}function cn(e,n){return B(e,"</")&&e.slice(2,2+n.length).toLowerCase()===n.toLowerCase()&&/[\t\r\n\f />]/.test(e[2+n.length]||">")}function Vs(e,n){Ae(e,n,bt(e,e.children[0]))}function bt(e,n){const{children:t}=e;return t.length===1&&n.type===1&&!je(n)}function Ae(e,n,t=!1){const{children:s}=e,r=s.length;let i=0;for(let l=0;l<s.length;l++){const o=s[l];if(o.type===1&&o.tagType===0){const c=t?0:U(o,n);if(c>0){if(c>=2){o.codegenNode.patchFlag="-1",o.codegenNode=n.hoist(o.codegenNode),i++;continue}}else{const a=o.codegenNode;if(a.type===13){const p=_t(a);if((!p||p===512||p===1)&&Et(o,n)>=2){const f=vt(o);f&&(a.props=n.hoist(f))}a.dynamicProps&&(a.dynamicProps=n.hoist(a.dynamicProps))}}}if(o.type===1){const c=o.tagType===1;c&&n.scopes.vSlot++,Ae(o,n),c&&n.scopes.vSlot--}else if(o.type===11)Ae(o,n,o.children.length===1);else if(o.type===9)for(let c=0;c<o.branches.length;c++)Ae(o.branches[c],n,o.branches[c].children.length===1)}i&&n.transformHoist&&n.transformHoist(s,n,e),i&&i===r&&e.type===1&&e.tagType===0&&e.codegenNode&&e.codegenNode.type===13&&re(e.codegenNode.children)&&(e.codegenNode.children=n.hoist(Ce(e.codegenNode.children)))}function U(e,n){const{constantCache:t}=n;switch(e.type){case 1:if(e.tagType!==0)return 0;const s=t.get(e);if(s!==void 0)return s;const r=e.codegenNode;if(r.type!==13||r.isBlock&&e.tag!=="svg"&&e.tag!=="foreignObject")return 0;if(_t(r))return t.set(e,0),0;{let o=3;const c=Et(e,n);if(c===0)return t.set(e,0),0;c<o&&(o=c);for(let a=0;a<e.children.length;a++){const p=U(e.children[a],n);if(p===0)return t.set(e,0),0;p<o&&(o=p)}if(o>1)for(let a=0;a<e.props.length;a++){const p=e.props[a];if(p.type===7&&p.name==="bind"&&p.exp){const f=U(p.exp,n);if(f===0)return t.set(e,0),0;f<o&&(o=f)}}if(r.isBlock){for(let a=0;a<e.props.length;a++)if(e.props[a].type===7)return t.set(e,0),0;n.removeHelper(x),n.removeHelper(ce(n.inSSR,r.isComponent)),r.isBlock=!1,n.helper(oe(n.inSSR,r.isComponent))}return t.set(e,o),o}case 2:case 3:return 3;case 9:case 11:case 10:return 0;case 5:case 12:return U(e.content,n);case 4:return e.constType;case 8:let l=3;for(let o=0;o<e.children.length;o++){const c=e.children[o];if(A(c)||un(c))continue;const a=U(c,n);if(a===0)return 0;a<l&&(l=a)}return l;default:return 0}}const Bs=new Set([Tn,Nn,be,Ne]);function St(e,n){if(e.type===14&&!A(e.callee)&&Bs.has(e.callee)){const t=e.arguments[0];if(t.type===4)return U(t,n);if(t.type===14)return St(t,n)}return 0}function Et(e,n){let t=3;const s=vt(e);if(s&&s.type===15){const{properties:r}=s;for(let i=0;i<r.length;i++){const{key:l,value:o}=r[i],c=U(l,n);if(c===0)return c;c<t&&(t=c);let a;if(o.type===4?a=U(o,n):o.type===14?a=St(o,n):a=0,a===0)return a;a<t&&(t=a)}}return t}function vt(e){const n=e.codegenNode;if(n.type===13)return n.props}function _t(e){const n=e.patchFlag;return n?parseInt(n,10):void 0}function Ds(e,{filename:n="",prefixIdentifiers:t=!1,hoistStatic:s=!1,cacheHandlers:r=!1,nodeTransforms:i=[],directiveTransforms:l={},transformHoist:o=null,isBuiltInComponent:c=Le,isCustomElement:a=Le,expressionPlugins:p=[],scopeId:f=null,slotted:h=!0,ssr:u=!1,inSSR:d=!1,ssrCssVars:m="",bindingMetadata:y=zt,inline:b=!1,isTS:T=!1,onError:w=hn,onWarn:ee=it,compatConfig:$}){const J=n.replace(/\?.*$/,"").match(/([^/\\]+)\.\w+$/),N={selfName:J&&st(Ge(J[1])),prefixIdentifiers:t,hoistStatic:s,cacheHandlers:r,nodeTransforms:i,directiveTransforms:l,transformHoist:o,isBuiltInComponent:c,isCustomElement:a,expressionPlugins:p,scopeId:f,slotted:h,ssr:u,inSSR:d,ssrCssVars:m,bindingMetadata:y,inline:b,isTS:T,onError:w,onWarn:ee,compatConfig:$,root:e,helpers:new Map,components:new Set,directives:new Set,hoists:[],imports:[],constantCache:new Map,temps:0,cached:0,identifiers:Object.create(null),scopes:{vFor:0,vSlot:0,vPre:0,vOnce:0},parent:null,currentNode:e,childIndex:0,inVOnce:!1,helper(g){const v=N.helpers.get(g)||0;return N.helpers.set(g,v+1),g},removeHelper(g){const v=N.helpers.get(g);if(v){const k=v-1;k?N.helpers.set(g,k):N.helpers.delete(g)}},helperString(g){return`_${ie[N.helper(g)]}`},replaceNode(g){N.parent.children[N.childIndex]=N.currentNode=g},removeNode(g){const v=N.parent.children,k=g?v.indexOf(g):N.currentNode?N.childIndex:-1;!g||g===N.currentNode?(N.currentNode=null,N.onNodeRemoved()):N.childIndex>k&&(N.childIndex--,N.onNodeRemoved()),N.parent.children.splice(k,1)},onNodeRemoved:()=>{},addIdentifiers(g){},removeIdentifiers(g){},hoist(g){A(g)&&(g=S(g)),N.hoists.push(g);const v=S(`_hoisted_${N.hoists.length}`,!1,g.loc,2);return v.hoisted=g,v},cache(g,v=!1){return us(N.cached++,g,v)}};return N.filters=new Set,N}function Fs(e,n){const t=Ds(e,n);Ze(e,t),n.hoistStatic&&Vs(e,t),n.ssr||Hs(e,t),e.helpers=new Set([...t.helpers.keys()]),e.components=[...t.components],e.directives=[...t.directives],e.imports=t.imports,e.hoists=t.hoists,e.temps=t.temps,e.cached=t.cached,e.filters=[...t.filters]}function Hs(e,n){const{helper:t}=n,{children:s}=e;if(s.length===1){const r=s[0];if(bt(e,r)&&r.codegenNode){const i=r.codegenNode;i.type===13&&In(i,n),e.codegenNode=i}else e.codegenNode=r}else if(s.length>1){let r=64;e.codegenNode=Se(n,t(ye),void 0,e.children,r+"",void 0,void 0,!0,void 0,!1)}}function Ws(e,n){let t=0;const s=()=>{t--};for(;t<e.children.length;t++){const r=e.children[t];A(r)||(n.parent=e,n.childIndex=t,n.onNodeRemoved=s,Ze(r,n))}}function Ze(e,n){n.currentNode=e;const{nodeTransforms:t}=n,s=[];for(let i=0;i<t.length;i++){const l=t[i](e,n);if(l&&(re(l)?s.push(...l):s.push(l)),n.currentNode)e=n.currentNode;else return}switch(e.type){case 3:n.ssr||n.helper(Te);break;case 5:n.ssr||n.helper(Je);break;case 9:for(let i=0;i<e.branches.length;i++)Ze(e.branches[i],n);break;case 10:case 11:case 1:case 0:Ws(e,n);break}n.currentNode=e;let r=s.length;for(;r--;)s[r]()}function Tt(e,n){const t=A(e)?s=>s===e:s=>e.test(s);return(s,r)=>{if(s.type===1){const{props:i}=s;if(s.tagType===3&&i.some(Es))return;const l=[];for(let o=0;o<i.length;o++){const c=i[o];if(c.type===7&&t(c.name)){i.splice(o,1),o--;const a=n(s,c,r);a&&l.push(a)}}return l}}}const Xe="/*#__PURE__*/",Nt=e=>`${ie[e]}: _${ie[e]}`;function jn(e,{mode:n="function",prefixIdentifiers:t=n==="module",sourceMap:s=!1,filename:r="template.vue.html",scopeId:i=null,optimizeImports:l=!1,runtimeGlobalName:o="Vue",runtimeModuleName:c="vue",ssrRuntimeModuleName:a="vue/server-renderer",ssr:p=!1,isTS:f=!1,inSSR:h=!1}){const u={mode:n,prefixIdentifiers:t,sourceMap:s,filename:r,scopeId:i,optimizeImports:l,runtimeGlobalName:o,runtimeModuleName:c,ssrRuntimeModuleName:a,ssr:p,isTS:f,inSSR:h,source:e.loc.source,code:"",column:1,line:1,offset:0,indentLevel:0,pure:!1,map:void 0,helper(m){return`_${ie[m]}`},push(m,y){u.code+=m},indent(){d(++u.indentLevel)},deindent(m=!1){m?--u.indentLevel:d(--u.indentLevel)},newline(){d(u.indentLevel)}};function d(m){u.push(`
`+"  ".repeat(m))}return u}function Ks(e,n={}){const t=jn(e,n);n.onContextCreated&&n.onContextCreated(t);const{mode:s,push:r,prefixIdentifiers:i,indent:l,deindent:o,newline:c,scopeId:a,ssr:p}=t,f=Array.from(e.helpers),h=f.length>0,u=!i&&s!=="module",d=!1,m=d?jn(e,n):t;js(e,m);const y=p?"ssrRender":"render",T=(p?["_ctx","_push","_parent","_attrs"]:["_ctx","_cache"]).join(", ");if(r(`function ${y}(${T}) {`),l(),u&&(r("with (_ctx) {"),l(),h&&(r(`const { ${f.map(Nt).join(", ")} } = _Vue`),r(`
`),c())),e.components.length&&(tn(e.components,"component",t),(e.directives.length||e.temps>0)&&c()),e.directives.length&&(tn(e.directives,"directive",t),e.temps>0&&c()),e.filters&&e.filters.length&&(c(),tn(e.filters,"filter",t),c()),e.temps>0){r("let ");for(let w=0;w<e.temps;w++)r(`${w>0?", ":""}_temp${w}`)}return(e.components.length||e.directives.length||e.temps)&&(r(`
`),c()),p||r("return "),e.codegenNode?D(e.codegenNode,t):r("null"),u&&(o(),r("}")),o(),r("}"),{ast:e,code:t.code,preamble:d?m.code:"",map:t.map?t.map.toJSON():void 0}}function js(e,n){const{ssr:t,prefixIdentifiers:s,push:r,newline:i,runtimeModuleName:l,runtimeGlobalName:o,ssrRuntimeModuleName:c}=n,a=o,p=Array.from(e.helpers);if(p.length>0&&(r(`const _Vue = ${a}
`),e.hoists.length)){const f=[mn,gn,Te,yn,at].filter(h=>p.includes(h)).map(Nt).join(", ");r(`const { ${f} } = _Vue
`)}Us(e.hoists,n),i(),r("return ")}function tn(e,n,{helper:t,push:s,newline:r,isTS:i}){const l=t(n==="filter"?En:n==="component"?bn:Sn);for(let o=0;o<e.length;o++){let c=e[o];const a=c.endsWith("__self");a&&(c=c.slice(0,-6)),s(`const ${Ee(c,n)} = ${l}(${JSON.stringify(c)}${a?", true":""})${i?"!":""}`),o<e.length-1&&r()}}function Us(e,n){if(!e.length)return;n.pure=!0;const{push:t,newline:s,helper:r,scopeId:i,mode:l}=n;s();for(let o=0;o<e.length;o++){const c=e[o];c&&(t(`const _hoisted_${o+1} = `),D(c,n),s())}n.pure=!1}function Rn(e,n){const t=e.length>3||!1;n.push("["),t&&n.indent(),Oe(e,n,t),t&&n.deindent(),n.push("]")}function Oe(e,n,t=!1,s=!0){const{push:r,newline:i}=n;for(let l=0;l<e.length;l++){const o=e[l];A(o)?r(o):re(o)?Rn(o,n):D(o,n),l<e.length-1&&(t?(s&&r(","),i()):s&&r(", "))}}function D(e,n){if(A(e)){n.push(e);return}if(un(e)){n.push(n.helper(e));return}switch(e.type){case 1:case 9:case 11:D(e.codegenNode,n);break;case 2:zs(e,n);break;case 4:Ct(e,n);break;case 5:Gs(e,n);break;case 12:D(e.codegenNode,n);break;case 8:Ot(e,n);break;case 3:Ys(e,n);break;case 13:qs(e,n);break;case 14:Xs(e,n);break;case 15:Qs(e,n);break;case 17:xs(e,n);break;case 18:er(e,n);break;case 19:nr(e,n);break;case 20:tr(e,n);break;case 21:Oe(e.body,n,!0,!1);break}}function zs(e,n){n.push(JSON.stringify(e.content),e)}function Ct(e,n){const{content:t,isStatic:s}=e;n.push(s?JSON.stringify(t):t,e)}function Gs(e,n){const{push:t,helper:s,pure:r}=n;r&&t(Xe),t(`${s(Je)}(`),D(e.content,n),t(")")}function Ot(e,n){for(let t=0;t<e.children.length;t++){const s=e.children[t];A(s)?n.push(s):D(s,n)}}function Js(e,n){const{push:t}=n;if(e.type===8)t("["),Ot(e,n),t("]");else if(e.isStatic){const s=Pn(e.content)?e.content:JSON.stringify(e.content);t(s,e)}else t(`[${e.content}]`,e)}function Ys(e,n){const{push:t,helper:s,pure:r}=n;r&&t(Xe),t(`${s(Te)}(${JSON.stringify(e.content)})`,e)}function qs(e,n){const{push:t,helper:s,pure:r}=n,{tag:i,props:l,children:o,patchFlag:c,dynamicProps:a,directives:p,isBlock:f,disableTracking:h,isComponent:u}=e;p&&t(s(vn)+"("),f&&t(`(${s(x)}(${h?"true":""}), `),r&&t(Xe);const d=f?ce(n.inSSR,u):oe(n.inSSR,u);t(s(d)+"(",e),Oe(Zs([i,l,o,c,a]),n),t(")"),f&&t(")"),p&&(t(", "),D(p,n),t(")"))}function Zs(e){let n=e.length;for(;n--&&e[n]==null;);return e.slice(0,n+1).map(t=>t||"null")}function Xs(e,n){const{push:t,helper:s,pure:r}=n,i=A(e.callee)?e.callee:s(e.callee);r&&t(Xe),t(i+"(",e),Oe(e.arguments,n),t(")")}function Qs(e,n){const{push:t,indent:s,deindent:r,newline:i}=n,{properties:l}=e;if(!l.length){t("{}",e);return}const o=l.length>1||!1;t(o?"{":"{ "),o&&s();for(let c=0;c<l.length;c++){const{key:a,value:p}=l[c];Js(a,n),t(": "),D(p,n),c<l.length-1&&(t(","),i())}o&&r(),t(o?"}":" }")}function xs(e,n){Rn(e.elements,n)}function er(e,n){const{push:t,indent:s,deindent:r}=n,{params:i,returns:l,body:o,newline:c,isSlot:a}=e;a&&t(`_${ie[On]}(`),t("(",e),re(i)?Oe(i,n):i&&D(i,n),t(") => "),(c||o)&&(t("{"),s()),l?(c&&t("return "),re(l)?Rn(l,n):D(l,n)):o&&D(o,n),(c||o)&&(r(),t("}")),a&&(e.isNonScopedSlot&&t(", undefined, true"),t(")"))}function nr(e,n){const{test:t,consequent:s,alternate:r,newline:i}=e,{push:l,indent:o,deindent:c,newline:a}=n;if(t.type===4){const f=!Pn(t.content);f&&l("("),Ct(t,n),f&&l(")")}else l("("),D(t,n),l(")");i&&o(),n.indentLevel++,i||l(" "),l("? "),D(s,n),n.indentLevel--,i&&a(),i||l(" "),l(": ");const p=r.type===19;p||n.indentLevel++,D(r,n),p||n.indentLevel--,i&&c(!0)}function tr(e,n){const{push:t,helper:s,indent:r,deindent:i,newline:l}=n;t(`_cache[${e.index}] || (`),e.isVNode&&(r(),t(`${s(Fe)}(-1),`),l()),t(`_cache[${e.index}] = `),D(e.value,n),e.isVNode&&(t(","),l(),t(`${s(Fe)}(1),`),l(),t(`_cache[${e.index}]`),i()),t(")")}new RegExp("\\b"+"arguments,await,break,case,catch,class,const,continue,debugger,default,delete,do,else,export,extends,finally,for,function,if,import,let,new,return,super,switch,throw,try,var,void,while,with,yield".split(",").join("\\b|\\b")+"\\b");const sr=Tt(/^(if|else|else-if)$/,(e,n,t)=>rr(e,n,t,(s,r,i)=>{const l=t.parent.children;let o=l.indexOf(s),c=0;for(;o-->=0;){const a=l[o];a&&a.type===9&&(c+=a.branches.length)}return()=>{if(i)s.codegenNode=zn(r,c,t);else{const a=ir(s.codegenNode);a.alternate=zn(r,c+s.branches.length-1,t)}}}));function rr(e,n,t,s){if(n.name!=="else"&&(!n.exp||!n.exp.content.trim())){const r=n.exp?n.exp.loc:e.loc;t.onError(P(28,n.loc)),n.exp=S("true",!1,r)}if(n.name==="if"){const r=Un(e,n),i={type:9,loc:e.loc,branches:[r]};if(t.replaceNode(i),s)return s(i,r,!0)}else{const r=t.parent.children;let i=r.indexOf(e);for(;i-->=-1;){const l=r[i];if(l&&l.type===3){t.removeNode(l);continue}if(l&&l.type===2&&!l.content.trim().length){t.removeNode(l);continue}if(l&&l.type===9){n.name==="else-if"&&l.branches[l.branches.length-1].condition===void 0&&t.onError(P(30,e.loc)),t.removeNode();const o=Un(e,n);l.branches.push(o);const c=s&&s(l,o,!1);Ze(o,t),c&&c(),t.currentNode=null}else t.onError(P(30,e.loc));break}}}function Un(e,n){const t=e.tagType===3;return{type:10,loc:e.loc,condition:n.name==="else"?void 0:n.exp,children:t&&!K(e,"for")?e.children:[e],userKey:Ye(e,"key"),isTemplateIf:t}}function zn(e,n,t){return e.condition?ln(e.condition,Gn(e,n,t),M(t.helper(Te),['""',"true"])):Gn(e,n,t)}function Gn(e,n,t){const{helper:s}=t,r=I("key",S(`${n}`,!1,W,2)),{children:i}=e,l=i[0];if(i.length!==1||l.type!==1)if(i.length===1&&l.type===11){const c=l.codegenNode;return Ue(c,r,t),c}else{let c=64;return Se(t,s(ye),j([r]),i,c+"",void 0,void 0,!0,!1,!1,e.loc)}else{const c=l.codegenNode,a=_s(c);return a.type===13&&In(a,t),Ue(a,r,t),c}}function ir(e){for(;;)if(e.type===19)if(e.alternate.type===19)e=e.alternate;else return e;else e.type===20&&(e=e.value)}const lr=Tt("for",(e,n,t)=>{const{helper:s,removeHelper:r}=t;return or(e,n,t,i=>{const l=M(s(_n),[i.source]),o=Ke(e),c=K(e,"memo"),a=Ye(e,"key"),p=a&&(a.type===6?S(a.value.content,!0):a.exp),f=a?I("key",p):null,h=i.source.type===4&&i.source.constType>0,u=h?64:a?128:256;return i.codegenNode=Se(t,s(ye),void 0,l,u+"",void 0,void 0,!0,!h,!1,e.loc),()=>{let d;const{children:m}=i,y=m.length!==1||m[0].type!==1,b=je(e)?e:o&&e.children.length===1&&je(e.children[0])?e.children[0]:null;if(b?(d=b.codegenNode,o&&f&&Ue(d,f,t)):y?d=Se(t,s(ye),f?j([f]):void 0,e.children,"64",void 0,void 0,!0,void 0,!1):(d=m[0].codegenNode,o&&f&&Ue(d,f,t),d.isBlock!==!h&&(d.isBlock?(r(x),r(ce(t.inSSR,d.isComponent))):r(oe(t.inSSR,d.isComponent))),d.isBlock=!h,d.isBlock?(s(x),s(ce(t.inSSR,d.isComponent))):s(oe(t.inSSR,d.isComponent))),c){const T=le(an(i.parseResult,[S("_cached")]));T.body=hs([G(["const _memo = (",c.exp,")"]),G(["if (_cached",...p?[" && _cached.key === ",p]:[],` && ${t.helperString(ut)}(_cached, _memo)) return _cached`]),G(["const _item = ",d]),S("_item.memo = _memo"),S("return _item")]),l.arguments.push(T,S("_cache"),S(String(t.cached++)))}else l.arguments.push(le(an(i.parseResult),d,!0))}})});function or(e,n,t,s){if(!n.exp){t.onError(P(31,n.loc));return}const r=kt(n.exp);if(!r){t.onError(P(32,n.loc));return}const{addIdentifiers:i,removeIdentifiers:l,scopes:o}=t,{source:c,value:a,key:p,index:f}=r,h={type:11,loc:n.loc,source:c,valueAlias:a,keyAlias:p,objectIndexAlias:f,parseResult:r,children:Ke(e)?e.children:[e]};t.replaceNode(h),o.vFor++;const u=s&&s(h);return()=>{o.vFor--,u&&u()}}const cr=/([\s\S]*?)\s+(?:in|of)\s+([\s\S]*)/,Jn=/,([^,\}\]]*)(?:,([^,\}\]]*))?$/,ar=/^\(|\)$/g;function kt(e,n){const t=e.loc,s=e.content,r=s.match(cr);if(!r)return;const[,i,l]=r,o={source:Me(t,l.trim(),s.indexOf(l,i.length)),value:void 0,key:void 0,index:void 0};let c=i.trim().replace(ar,"").trim();const a=i.indexOf(c),p=c.match(Jn);if(p){c=c.replace(Jn,"").trim();const f=p[1].trim();let h;if(f&&(h=s.indexOf(f,a+c.length),o.key=Me(t,f,h)),p[2]){const u=p[2].trim();u&&(o.index=Me(t,u,s.indexOf(u,o.key?h+f.length:a+c.length)))}}return c&&(o.value=Me(t,c,a)),o}function Me(e,n,t){return S(n,!1,mt(e,t,n.length))}function an({value:e,key:n,index:t},s=[]){return fr([e,n,t,...s])}function fr(e){let n=e.length;for(;n--&&!e[n];);return e.slice(0,n+1).map((t,s)=>t||S("_".repeat(s+1),!1))}const Yn=S("undefined",!1),pr=(e,n)=>{if(e.type===1&&(e.tagType===1||e.tagType===3)){const t=K(e,"slot");if(t)return t.exp,n.scopes.vSlot++,()=>{n.scopes.vSlot--}}},ur=(e,n,t)=>le(e,n,!1,!0,n.length?n[0].loc:t);function hr(e,n,t=ur){n.helper(On);const{children:s,loc:r}=e,i=[],l=[];let o=n.scopes.vSlot>0||n.scopes.vFor>0;const c=K(e,"slot",!0);if(c){const{arg:y,exp:b}=c;y&&!F(y)&&(o=!0),i.push(I(y||S("default",!0),t(b,s,r)))}let a=!1,p=!1;const f=[],h=new Set;let u=0;for(let y=0;y<s.length;y++){const b=s[y];let T;if(!Ke(b)||!(T=K(b,"slot",!0))){b.type!==3&&f.push(b);continue}if(c){n.onError(P(37,T.loc));break}a=!0;const{children:w,loc:ee}=b,{arg:$=S("default",!0),exp:J,loc:N}=T;let g;F($)?g=$?$.content:"default":o=!0;const v=t(J,w,ee);let k,E,O;if(k=K(b,"if"))o=!0,l.push(ln(k.exp,Re($,v,u++),Yn));else if(E=K(b,/^else(-if)?$/,!0)){let C=y,L;for(;C--&&(L=s[C],L.type===3););if(L&&Ke(L)&&K(L,"if")){s.splice(y,1),y--;let V=l[l.length-1];for(;V.alternate.type===19;)V=V.alternate;V.alternate=E.exp?ln(E.exp,Re($,v,u++),Yn):Re($,v,u++)}else n.onError(P(30,E.loc))}else if(O=K(b,"for")){o=!0;const C=O.parseResult||kt(O.exp);C?l.push(M(n.helper(_n),[C.source,le(an(C),Re($,v),!0)])):n.onError(P(32,O.loc))}else{if(g){if(h.has(g)){n.onError(P(38,N));continue}h.add(g),g==="default"&&(p=!0)}i.push(I($,v))}}if(!c){const y=(b,T)=>{const w=t(b,T,r);return n.compatConfig&&(w.isNonScopedSlot=!0),I("default",w)};a?f.length&&f.some(b=>Pt(b))&&(p?n.onError(P(39,f[0].loc)):i.push(y(void 0,f))):i.push(y(void 0,s))}const d=o?2:$e(e.children)?3:1;let m=j(i.concat(I("_",S(d+"",!1))),r);return l.length&&(m=M(n.helper(pt),[m,Ce(l)])),{slots:m,hasDynamicSlots:o}}function Re(e,n,t){const s=[I("name",e),I("fn",n)];return t!=null&&s.push(I("key",S(String(t),!0))),j(s)}function $e(e){for(let n=0;n<e.length;n++){const t=e[n];switch(t.type){case 1:if(t.tagType===2||$e(t.children))return!0;break;case 9:if($e(t.branches))return!0;break;case 10:case 11:if($e(t.children))return!0;break}}return!1}function Pt(e){return e.type!==2&&e.type!==12?!0:e.type===2?!!e.content.trim():Pt(e.content)}const It=new WeakMap,dr=(e,n)=>function(){if(e=n.currentNode,!(e.type===1&&(e.tagType===0||e.tagType===1)))return;const{tag:s,props:r}=e,i=e.tagType===1;let l=i?mr(e,n):`"${s}"`;const o=Jt(l)&&l.callee===Be;let c,a,p,f=0,h,u,d,m=o||l===me||l===dn||!i&&(s==="svg"||s==="foreignObject");if(r.length>0){const y=Mt(e,n,void 0,i,o);c=y.props,f=y.patchFlag,u=y.dynamicPropNames;const b=y.directives;d=b&&b.length?Ce(b.map(T=>yr(T,n))):void 0,y.shouldUseBlock&&(m=!0)}if(e.children.length>0)if(l===Ve&&(m=!0,f|=1024),i&&l!==me&&l!==Ve){const{slots:b,hasDynamicSlots:T}=hr(e,n);a=b,T&&(f|=1024)}else if(e.children.length===1&&l!==me){const b=e.children[0],T=b.type,w=T===5||T===8;w&&U(b,n)===0&&(f|=1),w||T===2?a=b:a=e.children}else a=e.children;f!==0&&(p=String(f),u&&u.length&&(h=br(u))),e.codegenNode=Se(n,l,c,a,p,h,d,!!m,!1,i,e.loc)};function mr(e,n,t=!1){let{tag:s}=e;const r=fn(s),i=Ye(e,"is");if(i)if(r||Q("COMPILER_IS_ON_ELEMENT",n)){const c=i.type===6?i.value&&S(i.value.content,!0):i.exp;if(c)return M(n.helper(Be),[c])}else i.type===6&&i.value.content.startsWith("vue:")&&(s=i.value.content.slice(4));const l=!r&&K(e,"is");if(l&&l.exp)return M(n.helper(Be),[l.exp]);const o=ht(s)||n.isBuiltInComponent(s);return o?(t||n.helper(o),o):(n.helper(bn),n.components.add(s),Ee(s,"component"))}function Mt(e,n,t=e.props,s,r,i=!1){const{tag:l,loc:o,children:c}=e;let a=[];const p=[],f=[],h=c.length>0;let u=!1,d=0,m=!1,y=!1,b=!1,T=!1,w=!1,ee=!1;const $=[],J=v=>{a.length&&(p.push(j(qn(a),o)),a=[]),v&&p.push(v)},N=({key:v,value:k})=>{if(F(v)){const E=v.content,O=rt(E);if(O&&(!s||r)&&E.toLowerCase()!=="onclick"&&E!=="onUpdate:modelValue"&&!An(E)&&(T=!0),O&&An(E)&&(ee=!0),k.type===20||(k.type===4||k.type===8)&&U(k,n)>0)return;E==="ref"?m=!0:E==="class"?y=!0:E==="style"?b=!0:E!=="key"&&!$.includes(E)&&$.push(E),s&&(E==="class"||E==="style")&&!$.includes(E)&&$.push(E)}else w=!0};for(let v=0;v<t.length;v++){const k=t[v];if(k.type===6){const{loc:E,name:O,value:C}=k;let L=!0;if(O==="ref"&&(m=!0,n.scopes.vFor>0&&a.push(I(S("ref_for",!0),S("true")))),O==="is"&&(fn(l)||C&&C.content.startsWith("vue:")||Q("COMPILER_IS_ON_ELEMENT",n)))continue;a.push(I(S(O,!0,mt(E,0,O.length)),S(C?C.content:"",L,C?C.loc:E)))}else{const{name:E,arg:O,exp:C,loc:L}=k,V=E==="bind",ke=E==="on";if(E==="slot"){s||n.onError(P(40,L));continue}if(E==="once"||E==="memo"||E==="is"||V&&X(O,"is")&&(fn(l)||Q("COMPILER_IS_ON_ELEMENT",n))||ke&&i)continue;if((V&&X(O,"key")||ke&&h&&X(O,"vue:before-update"))&&(u=!0),V&&X(O,"ref")&&n.scopes.vFor>0&&a.push(I(S("ref_for",!0),S("true"))),!O&&(V||ke)){if(w=!0,C)if(V){if(J(),Q("COMPILER_V_BIND_OBJECT_ORDER",n)){p.unshift(C);continue}p.push(C)}else J({type:14,loc:L,callee:n.helper(Cn),arguments:s?[C]:[C,"true"]});else n.onError(P(V?34:35,L));continue}const wn=n.directiveTransforms[E];if(wn){const{props:Qe,needRuntime:xe}=wn(k,e,n);!i&&Qe.forEach(N),ke&&O&&!F(O)?J(j(Qe,o)):a.push(...Qe),xe&&(f.push(k),un(xe)&&It.set(k,xe))}else Yt(E)||(f.push(k),h&&(u=!0))}}let g;if(p.length?(J(),p.length>1?g=M(n.helper(De),p,o):g=p[0]):a.length&&(g=j(qn(a),o)),w?d|=16:(y&&!s&&(d|=2),b&&!s&&(d|=4),$.length&&(d|=8),T&&(d|=32)),!u&&(d===0||d===32)&&(m||ee||f.length>0)&&(d|=512),!n.inSSR&&g)switch(g.type){case 15:let v=-1,k=-1,E=!1;for(let L=0;L<g.properties.length;L++){const V=g.properties[L].key;F(V)?V.content==="class"?v=L:V.content==="style"&&(k=L):V.isHandlerKey||(E=!0)}const O=g.properties[v],C=g.properties[k];E?g=M(n.helper(be),[g]):(O&&!F(O.value)&&(O.value=M(n.helper(Tn),[O.value])),C&&(b||C.value.type===4&&C.value.content.trim()[0]==="["||C.value.type===17)&&(C.value=M(n.helper(Nn),[C.value])));break;case 14:break;default:g=M(n.helper(be),[M(n.helper(Ne),[g])]);break}return{props:g,directives:f,patchFlag:d,dynamicPropNames:$,shouldUseBlock:u}}function qn(e){const n=new Map,t=[];for(let s=0;s<e.length;s++){const r=e[s];if(r.key.type===8||!r.key.isStatic){t.push(r);continue}const i=r.key.content,l=n.get(i);l?(i==="style"||i==="class"||rt(i))&&gr(l,r):(n.set(i,r),t.push(r))}return t}function gr(e,n){e.value.type===17?e.value.elements.push(n.value):e.value=Ce([e.value,n.value],e.loc)}function yr(e,n){const t=[],s=It.get(e);s?t.push(n.helperString(s)):(n.helper(Sn),n.directives.add(e.name),t.push(Ee(e.name,"directive")));const{loc:r}=e;if(e.exp&&t.push(e.exp),e.arg&&(e.exp||t.push("void 0"),t.push(e.arg)),Object.keys(e.modifiers).length){e.arg||(e.exp||t.push("void 0"),t.push("void 0"));const i=S("true",!1,r);t.push(j(e.modifiers.map(l=>I(l,i)),r))}return Ce(t,e.loc)}function br(e){let n="[";for(let t=0,s=e.length;t<s;t++)n+=JSON.stringify(e[t]),t<s-1&&(n+=", ");return n+"]"}function fn(e){return e==="component"||e==="Component"}const Sr=e=>{const n=Object.create(null);return t=>n[t]||(n[t]=e(t))},Er=/-(\w)/g,Zn=Sr(e=>e.replace(Er,(n,t)=>t?t.toUpperCase():"")),vr=(e,n)=>{if(je(e)){const{children:t,loc:s}=e,{slotName:r,slotProps:i}=_r(e,n),l=[n.prefixIdentifiers?"_ctx.$slots":"$slots",r,"{}","undefined","true"];let o=2;i&&(l[2]=i,o=3),t.length&&(l[3]=le([],t,!1,!1,s),o=4),n.scopeId&&!n.slotted&&(o=5),l.splice(o),e.codegenNode=M(n.helper(ft),l,s)}};function _r(e,n){let t='"default"',s;const r=[];for(let i=0;i<e.props.length;i++){const l=e.props[i];l.type===6?l.value&&(l.name==="name"?t=JSON.stringify(l.value.content):(l.name=Zn(l.name),r.push(l))):l.name==="bind"&&X(l.arg,"name")?l.exp&&(t=l.exp):(l.name==="bind"&&l.arg&&F(l.arg)&&(l.arg.content=Zn(l.arg.content)),r.push(l))}if(r.length>0){const{props:i,directives:l}=Mt(e,n,r,!1,!1);s=i,l.length&&n.onError(P(36,l[0].loc))}return{slotName:t,slotProps:s}}const Tr=/^\s*([\w$_]+|(async\s*)?\([^)]*?\))\s*(:[^=]+)?=>|^\s*(async\s+)?function(?:\s+[\w$]+)?\s*\(/,Rt=(e,n,t,s)=>{const{loc:r,modifiers:i,arg:l}=e;!e.exp&&!i.length&&t.onError(P(35,r));let o;if(l.type===4)if(l.isStatic){let f=l.content;f.startsWith("vue:")&&(f=`vnode-${f.slice(4)}`);const h=n.tagType!==0||f.startsWith("vnode")||!/[A-Z]/.test(f)?Gt(Ge(f)):`on:${f}`;o=S(h,!0,l.loc)}else o=G([`${t.helperString(rn)}(`,l,")"]);else o=l,o.children.unshift(`${t.helperString(rn)}(`),o.children.push(")");let c=e.exp;c&&!c.content.trim()&&(c=void 0);let a=t.cacheHandlers&&!c&&!t.inVOnce;if(c){const f=dt(c.content),h=!(f||Tr.test(c.content)),u=c.content.includes(";");(h||a&&f)&&(c=G([`${h?"$event":"(...args)"} => ${u?"{":"("}`,c,u?"}":")"]))}let p={props:[I(o,c||S("() => {}",!1,r))]};return s&&(p=s(p)),a&&(p.props[0].value=t.cache(p.props[0].value)),p.props.forEach(f=>f.key.isHandlerKey=!0),p},Nr=(e,n,t)=>{const{exp:s,modifiers:r,loc:i}=e,l=e.arg;return l.type!==4?(l.children.unshift("("),l.children.push(') || ""')):l.isStatic||(l.content=`${l.content} || ""`),r.includes("camel")&&(l.type===4?l.isStatic?l.content=Ge(l.content):l.content=`${t.helperString(sn)}(${l.content})`:(l.children.unshift(`${t.helperString(sn)}(`),l.children.push(")"))),t.inSSR||(r.includes("prop")&&Xn(l,"."),r.includes("attr")&&Xn(l,"^")),!s||s.type===4&&!s.content.trim()?(t.onError(P(34,i)),{props:[I(l,S("",!0,i))]}):{props:[I(l,s)]}},Xn=(e,n)=>{e.type===4?e.isStatic?e.content=n+e.content:e.content=`\`${n}\${${e.content}}\``:(e.children.unshift(`'${n}' + (`),e.children.push(")"))},Cr=(e,n)=>{if(e.type===0||e.type===1||e.type===11||e.type===10)return()=>{const t=e.children;let s,r=!1;for(let i=0;i<t.length;i++){const l=t[i];if(nn(l)){r=!0;for(let o=i+1;o<t.length;o++){const c=t[o];if(nn(c))s||(s=t[i]=G([l],l.loc)),s.children.push(" + ",c),t.splice(o,1),o--;else{s=void 0;break}}}}if(!(!r||t.length===1&&(e.type===0||e.type===1&&e.tagType===0&&!e.props.find(i=>i.type===7&&!n.directiveTransforms[i.name])&&e.tag!=="template")))for(let i=0;i<t.length;i++){const l=t[i];if(nn(l)||l.type===8){const o=[];(l.type!==2||l.content!==" ")&&o.push(l),!n.ssr&&U(l,n)===0&&o.push("1"),t[i]={type:12,content:l,loc:l.loc,codegenNode:M(n.helper(yn),o)}}}}},Qn=new WeakSet,Or=(e,n)=>{if(e.type===1&&K(e,"once",!0))return Qn.has(e)||n.inVOnce?void 0:(Qn.add(e),n.inVOnce=!0,n.helper(Fe),()=>{n.inVOnce=!1;const t=n.currentNode;t.codegenNode&&(t.codegenNode=n.cache(t.codegenNode,!0))})},wt=(e,n,t)=>{const{exp:s,arg:r}=e;if(!s)return t.onError(P(41,e.loc)),we();const i=s.loc.source,l=s.type===4?s.content:i,o=t.bindingMetadata[i];if(o==="props"||o==="props-aliased")return t.onError(P(44,s.loc)),we();const c=!1;if(!l.trim()||!dt(l)&&!c)return t.onError(P(42,s.loc)),we();const a=r||S("modelValue",!0),p=r?F(r)?`onUpdate:${Ge(r.content)}`:G(['"onUpdate:" + ',r]):"onUpdate:modelValue";let f;const h=t.isTS?"($event: any)":"$event";f=G([`${h} => ((`,s,") = $event)"]);const u=[I(a,e.exp),I(p,f)];if(e.modifiers.length&&n.tagType===1){const d=e.modifiers.map(y=>(Pn(y)?y:JSON.stringify(y))+": true").join(", "),m=r?F(r)?`${r.content}Modifiers`:G([r,' + "Modifiers"']):"modelModifiers";u.push(I(m,S(`{ ${d} }`,!1,e.loc,2)))}return we(u)};function we(e=[]){return{props:e}}const kr=/[\w).+\-_$\]]/,Pr=(e,n)=>{Q("COMPILER_FILTER",n)&&(e.type===5&&ze(e.content,n),e.type===1&&e.props.forEach(t=>{t.type===7&&t.name!=="for"&&t.exp&&ze(t.exp,n)}))};function ze(e,n){if(e.type===4)xn(e,n);else for(let t=0;t<e.children.length;t++){const s=e.children[t];typeof s=="object"&&(s.type===4?xn(s,n):s.type===8?ze(e,n):s.type===5&&ze(s.content,n))}}function xn(e,n){const t=e.content;let s=!1,r=!1,i=!1,l=!1,o=0,c=0,a=0,p=0,f,h,u,d,m=[];for(u=0;u<t.length;u++)if(h=f,f=t.charCodeAt(u),s)f===39&&h!==92&&(s=!1);else if(r)f===34&&h!==92&&(r=!1);else if(i)f===96&&h!==92&&(i=!1);else if(l)f===47&&h!==92&&(l=!1);else if(f===124&&t.charCodeAt(u+1)!==124&&t.charCodeAt(u-1)!==124&&!o&&!c&&!a)d===void 0?(p=u+1,d=t.slice(0,u).trim()):y();else{switch(f){case 34:r=!0;break;case 39:s=!0;break;case 96:i=!0;break;case 40:a++;break;case 41:a--;break;case 91:c++;break;case 93:c--;break;case 123:o++;break;case 125:o--;break}if(f===47){let b=u-1,T;for(;b>=0&&(T=t.charAt(b),T===" ");b--);(!T||!kr.test(T))&&(l=!0)}}d===void 0?d=t.slice(0,u).trim():p!==0&&y();function y(){m.push(t.slice(p,u).trim()),p=u+1}if(m.length){for(u=0;u<m.length;u++)d=Ir(d,m[u],n);e.content=d}}function Ir(e,n,t){t.helper(En);const s=n.indexOf("(");if(s<0)return t.filters.add(n),`${Ee(n,"filter")}(${e})`;{const r=n.slice(0,s),i=n.slice(s+1);return t.filters.add(r),`${Ee(r,"filter")}(${e}${i!==")"?","+i:i}`}}const et=new WeakSet,Mr=(e,n)=>{if(e.type===1){const t=K(e,"memo");return!t||et.has(e)?void 0:(et.add(e),()=>{const s=e.codegenNode||n.currentNode.codegenNode;s&&s.type===13&&(e.tagType!==1&&In(s,n),e.codegenNode=M(n.helper(kn),[t.exp,le(void 0,s),"_cache",String(n.cached++)]))})}};function Rr(e){return[[Or,sr,Mr,lr,Pr,vr,dr,pr,Cr],{on:Rt,bind:Nr,model:wt}]}function wr(e,n={}){const t=n.onError||hn,s=n.mode==="module";n.prefixIdentifiers===!0?t(P(47)):s&&t(P(48));const r=!1;n.cacheHandlers&&t(P(49)),n.scopeId&&!s&&t(P(50));const i=A(e)?Cs(e,n):e,[l,o]=Rr();return Fs(i,Y({},n,{prefixIdentifiers:r,nodeTransforms:[...l,...n.nodeTransforms||[]],directiveTransforms:Y({},o,n.directiveTransforms||{})})),Ks(i,Y({},n,{prefixIdentifiers:r}))}const Ar=()=>({props:[]}),At=Symbol(""),$t=Symbol(""),Lt=Symbol(""),Vt=Symbol(""),pn=Symbol(""),Bt=Symbol(""),Dt=Symbol(""),Ft=Symbol(""),Ht=Symbol(""),Wt=Symbol("");fs({[At]:"vModelRadio",[$t]:"vModelCheckbox",[Lt]:"vModelText",[Vt]:"vModelSelect",[pn]:"vModelDynamic",[Bt]:"withModifiers",[Dt]:"withKeys",[Ft]:"vShow",[Ht]:"Transition",[Wt]:"TransitionGroup"});let te;function $r(e,n=!1){return te||(te=document.createElement("div")),n?(te.innerHTML=`<div foo="${e.replace(/"/g,"&quot;")}">`,te.children[0].getAttribute("foo")):(te.innerHTML=e,te.textContent)}const Lr=ae("style,iframe,script,noscript",!0),Vr={isVoidTag:qt,isNativeTag:e=>Zt(e)||Xt(e),isPreTag:e=>e==="pre",decodeEntities:$r,isBuiltInComponent:e=>{if(se(e,"Transition"))return Ht;if(se(e,"TransitionGroup"))return Wt},getNamespace(e,n){let t=n?n.ns:0;if(n&&t===2)if(n.tag==="annotation-xml"){if(e==="svg")return 1;n.props.some(s=>s.type===6&&s.name==="encoding"&&s.value!=null&&(s.value.content==="text/html"||s.value.content==="application/xhtml+xml"))&&(t=0)}else/^m(?:[ions]|text)$/.test(n.tag)&&e!=="mglyph"&&e!=="malignmark"&&(t=0);else n&&t===1&&(n.tag==="foreignObject"||n.tag==="desc"||n.tag==="title")&&(t=0);if(t===0){if(e==="svg")return 1;if(e==="math")return 2}return t},getTextMode({tag:e,ns:n}){if(n===0){if(e==="textarea"||e==="title")return 1;if(Lr(e))return 2}return 0}},Br=e=>{e.type===1&&e.props.forEach((n,t)=>{n.type===6&&n.name==="style"&&n.value&&(e.props[t]={type:7,name:"bind",arg:S("style",!0,n.loc),exp:Dr(n.value.content,n.loc),modifiers:[],loc:n.loc})})},Dr=(e,n)=>{const t=Qt(e);return S(JSON.stringify(t),!1,n,3)};function q(e,n){return P(e,n)}const Fr=(e,n,t)=>{const{exp:s,loc:r}=e;return s||t.onError(q(51,r)),n.children.length&&(t.onError(q(52,r)),n.children.length=0),{props:[I(S("innerHTML",!0,r),s||S("",!0))]}},Hr=(e,n,t)=>{const{exp:s,loc:r}=e;return s||t.onError(q(53,r)),n.children.length&&(t.onError(q(54,r)),n.children.length=0),{props:[I(S("textContent",!0),s?U(s,t)>0?s:M(t.helperString(Je),[s],r):S("",!0))]}},Wr=(e,n,t)=>{const s=wt(e,n,t);if(!s.props.length||n.tagType===1)return s;e.arg&&t.onError(q(56,e.arg.loc));const{tag:r}=n,i=t.isCustomElement(r);if(r==="input"||r==="textarea"||r==="select"||i){let l=Lt,o=!1;if(r==="input"||i){const c=Ye(n,"type");if(c){if(c.type===7)l=pn;else if(c.value)switch(c.value.content){case"radio":l=At;break;case"checkbox":l=$t;break;case"file":o=!0,t.onError(q(57,e.loc));break}}else Ss(n)&&(l=pn)}else r==="select"&&(l=Vt);o||(s.needRuntime=t.helper(l))}else t.onError(q(55,e.loc));return s.props=s.props.filter(l=>!(l.key.type===4&&l.key.content==="modelValue")),s},Kr=ae("passive,once,capture"),jr=ae("stop,prevent,self,ctrl,shift,alt,meta,exact,middle"),Ur=ae("left,right"),Kt=ae("onkeyup,onkeydown,onkeypress",!0),zr=(e,n,t,s)=>{const r=[],i=[],l=[];for(let o=0;o<n.length;o++){const c=n[o];c==="native"&&ve("COMPILER_V_ON_NATIVE",t)||Kr(c)?l.push(c):Ur(c)?F(e)?Kt(e.content)?r.push(c):i.push(c):(r.push(c),i.push(c)):jr(c)?i.push(c):r.push(c)}return{keyModifiers:r,nonKeyModifiers:i,eventOptionModifiers:l}},nt=(e,n)=>F(e)&&e.content.toLowerCase()==="onclick"?S(n,!0):e.type!==4?G(["(",e,`) === "onClick" ? "${n}" : (`,e,")"]):e,Gr=(e,n,t)=>Rt(e,n,t,s=>{const{modifiers:r}=e;if(!r.length)return s;let{key:i,value:l}=s.props[0];const{keyModifiers:o,nonKeyModifiers:c,eventOptionModifiers:a}=zr(i,r,t,e.loc);if(c.includes("right")&&(i=nt(i,"onContextmenu")),c.includes("middle")&&(i=nt(i,"onMouseup")),c.length&&(l=M(t.helper(Bt),[l,JSON.stringify(c)])),o.length&&(!F(i)||Kt(i.content))&&(l=M(t.helper(Dt),[l,JSON.stringify(o)])),a.length){const p=a.map(st).join("");i=F(i)?S(`${i.content}${p}`,!0):G(["(",i,`) + "${p}"`])}return{props:[I(i,l)]}}),Jr=(e,n,t)=>{const{exp:s,loc:r}=e;return s||t.onError(q(59,r)),{props:[],needRuntime:t.helper(Ft)}},Yr=(e,n)=>{e.type===1&&e.tagType===0&&(e.tag==="script"||e.tag==="style")&&(n.onError(q(61,e.loc)),n.removeNode())},qr=[Br],Zr={cloak:Ar,html:Fr,text:Hr,model:Wr,on:Gr,show:Jr};function Xr(e,n={}){return wr(e,Y({},Vr,n,{nodeTransforms:[Yr,...qr,...n.nodeTransforms||[]],directiveTransforms:Y({},Zr,n.directiveTransforms||{}),transformHoist:null}))}const tt=Object.create(null);function jt(e,n){if(!A(e))if(e.nodeType)e=e.innerHTML;else return Le;const t=e,s=tt[t];if(s)return s;if(e[0]==="#"){const o=document.querySelector(e);e=o?o.innerHTML:""}const r=Y({hoistStatic:!0,onError:void 0,onWarn:Le},n);!r.isCustomElement&&typeof customElements<"u"&&(r.isCustomElement=o=>!!customElements.get(o));const{code:i}=Xr(e,r),l=new Function("Vue",i)(es);return l._rc=!0,tt[t]=l}xt(jt);const Qr={name:"docInfo",props:["info"],setup(e){return jt(e.info)}};const xr={class:"container"},ei={class:"section"},ni=["onClick"],ti={__name:"doc",setup(e){let n=fe(!1),t=fe("提示"),s=fe(""),r=fe(rs);const i=fe(null);function l(o){n.value=!0,t.value=o.name,s.value=o.content}return(o,c)=>{const a=ne("Select"),p=ne("el-icon"),f=ne("SemiSelect"),h=ne("el-col"),u=ne("el-row"),d=ne("el-dialog");return pe(),Pe("div",xr,[(pe(!0),Pe($n,null,Ln(Ie(r),m=>(pe(),Pe("section",ei,[he("h5",null,Vn(m.title),1),Z(u,{gutter:20},{default:ue(()=>[(pe(!0),Pe($n,null,Ln(m.children,y=>(pe(),ss(h,{sm:6,xs:12,lg:4},{default:ue(()=>[he("div",{class:"section-body-item",onClick:b=>l(y)},[he("p",null,Vn(y.name)+" ",1),he("p",null,[Z(p,null,{default:ue(()=>[Z(a)]),_:1}),Z(p,null,{default:ue(()=>[Z(f)]),_:1})])],8,ni)]),_:2},1024))),256))]),_:2},1024)]))),256)),Z(d,{modelValue:Ie(n),"onUpdate:modelValue":c[0]||(c[0]=m=>ts(n)?n.value=m:n=m),title:Ie(t),width:"100%","destroy-on-close":""},{default:ue(()=>[he("div",{style:{"font-size":"14px"},class:"doc-Info",ref_key:"infoBody",ref:i},[Z(Qr,{info:Ie(s)},null,8,["info"])],512)]),_:1},8,["modelValue","title"])])}}},ri=ns(ti,[["__scopeId","data-v-d2cb6397"]]);export{ri as default};
